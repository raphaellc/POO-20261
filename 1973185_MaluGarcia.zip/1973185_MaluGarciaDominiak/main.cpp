// ============================================================
//  main.cpp  –  Funcao principal / Cenario de uso
//  *** PREENCHA OS BLOCOS MARCADOS COM TODO ***
// ============================================================
#include <iostream>
#include <iomanip>
#include "GerenciadoraVeiculos.h"
#include "CarroPasseio.h"
#include "Caminhao.h"


int main() {
    GerenciadoraVeiculos gestor;

    CarroPasseio* carro = new CarroPasseio("ABC-1234", 10000);
    Caminhao* caminhao = new Caminhao("XYZ-9876", 50000);

    gestor.adicionarVeiculo(carro);
    gestor.adicionarVeiculo(caminhao);

    std::cout << "\n--- Relatorio de Manutencao ---" << std::endl;
    gestor.exibirRelatorioManutencao();

    std::cout << "Custo total da frota: R$ "
              << std::fixed << std::setprecision(2)
              << gestor.calcularCustoTotal() << std::endl;

    return 0;
}
