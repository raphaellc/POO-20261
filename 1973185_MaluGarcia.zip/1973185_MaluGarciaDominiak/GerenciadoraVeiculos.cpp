#include "GerenciadoraVeiculos.h"
#include <iostream>
#include <iomanip>

GerenciadoraVeiculos::GerenciadoraVeiculos() {}

GerenciadoraVeiculos::~GerenciadoraVeiculos() {
    for (auto v : frota) {
        delete v;
    }
    std::cout << "Gerenciadora de Veiculos destruida" << std::endl;
}
void GerenciadoraVeiculos::adicionarVeiculo(Veiculo* v) {
    frota.push_back(v);
}
void GerenciadoraVeiculos::exibirRelatorioManutencao() {
    for (auto v : frota) {
        std::cout << "Placa: " << v->getPlaca()
                  << " | Custo manutencao: R$ "
                  << std::fixed << std::setprecision(2)
                  << v->calcularManutencao() << std::endl;
    }
}
float GerenciadoraVeiculos::calcularCustoTotal() {
    float total = 0.0f;
    for (auto v : frota) {
        total += v->calcularManutencao();
    }
    return total;
}

