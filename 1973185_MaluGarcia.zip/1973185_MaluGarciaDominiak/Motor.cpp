#include "Motor.h"
#include <iostream>

Motor::Motor(int potencia, std::string tipo) : potencia(potencia), tipoCombustivel(tipo) {
    std::cout << "Motor criado (" << potencia << " cv, " << tipo << ")" << std::endl;
}
Motor::~Motor() {
    std::cout << "Motor destruido" << std::endl;
}
int Motor::getPotencia() { return potencia; }
std::string Motor::getTipoCombustivel() { return tipoCombustivel; }

