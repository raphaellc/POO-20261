#include "Veiculo.h"
#include <iostream>

Veiculo::Veiculo(std::string placa, int quilometragem, int potenciaMotor)
    : placa(placa), quilometragem(quilometragem) {
    motor = new Motor(potenciaMotor, "Diesel");
    std::cout << "Veiculo criado: " << placa << std::endl;
}
Veiculo::~Veiculo() {
    delete motor;
    std::cout << "Veiculo destruudo: " << placa << std::endl;
}
std::string Veiculo::getPlaca() { return placa; }
int Veiculo::getQuilometragem() { return quilometragem; }

